import 'package:flutter/material.dart';
class AppColors {
  AppColors._();
  static const charcoal = Color(0xFF171513);
  static const gold = Color(0xFFC7A45A);
  static const deepGold = Color(0xFF9C7734);
  static const ivory = Color(0xFFF8F4EC);
  static const surface = Color(0xFFFFFCF7);
  static const line = Color(0xFFEAE1D2);
  static const muted = Color(0xFF786F64);
  static const success = Color(0xFF327A53);
  static const danger = Color(0xFFA34141);
}
