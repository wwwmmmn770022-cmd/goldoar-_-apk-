import '../config/app_config.dart';
class MediaUrl {
  MediaUrl._();
  static String resolve(String? path) {
    if (path == null || path.trim().isEmpty) return '';
    if (path.startsWith('http://') || path.startsWith('https://')) return path;
    final clean = path.startsWith('/') ? path : '/$path';
    return '${AppConfig.mediaBaseUrl}$clean';
  }
}
