import 'package:intl/intl.dart';
class PriceFormatter {
  PriceFormatter._();
  static final _number = NumberFormat('#,##0.##', 'en');
  static String format(String? value, String currency) {
    final parsed = num.tryParse(value ?? '');
    if (parsed == null) return 'السعر عند الطلب';
    return '${_number.format(parsed)} $currency';
  }
}
