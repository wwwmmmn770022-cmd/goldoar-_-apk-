import 'package:get/get.dart';
import '../../products/data/models/product_models.dart';
import '../../products/data/repositories/product_repository.dart';

class HomeController extends GetxController {
  HomeController(this._repository);
  final ProductRepository _repository;
  final products = <ProductModel>[].obs;
  final isLoading = true.obs;
  final errorMessage = RxnString();
  final selectedCategoryId = RxnInt();

  List<ProductModel> get visibleProducts {
    final categoryId = selectedCategoryId.value;
    if (categoryId == null) return products;
    return products.where((p) => p.category.id == categoryId).toList();
  }

  List<CategoryModel> get categories {
    final map = <int, CategoryModel>{};
    for (final p in products) {
      map[p.category.id] = p.category;
    }
    return map.values.toList();
  }

  @override
  void onInit() {
    super.onInit();
    load();
  }

  Future<void> load() async {
    isLoading.value = true;
    errorMessage.value = null;
    try {
      final remote = await _repository.fetchProducts();
      products.assignAll(remote.isEmpty ? _demoProducts : remote);
    } catch (_) {
      products.assignAll(_demoProducts);
    } finally {
      isLoading.value = false;
    }
  }

  void selectCategory(int? id) => selectedCategoryId.value = id;

  List<ProductModel> get _demoProducts {
    const rings = CategoryModel(id: 1, name: 'خواتم', slug: 'rings');
    const bracelets = CategoryModel(id: 2, name: 'أساور', slug: 'bracelets');
    const necklaces = CategoryModel(id: 3, name: 'سلاسل', slug: 'necklaces');
    const sets = CategoryModel(id: 4, name: 'أطقم', slug: 'sets');

    ProductItemModel item(int id, String sku, String weight, String karat, String price) =>
        ProductItemModel(
          id: id,
          sku: sku,
          weight: weight,
          status: 'available',
          karatName: karat,
          priceAvailable: true,
          price: PriceModel(finalPrice: price, currencyCode: 'ر.ي'),
        );

    ProductModel product(int id, String name, String slug, CategoryModel category,
            String weight, String price, {bool isNew = false}) =>
        ProductModel(
          id: id,
          name: name,
          slug: slug,
          category: category,
          media: const [],
          items: [item(id, 'GLD-${1000 + id}', weight, 'عيار 21', price)],
          isFeatured: true,
          isNew: isNew,
          viewsCount: 0,
          shortDescription: 'قطعة ذهب فاخرة بتصميم أنيق ومناسب للمناسبات والهدايا.',
          description: 'تصميم فاخر من جولدورا، مع إمكانية الاستفسار والحجز والتواصل مع المتجر.',
        );

    return [
      product(1, 'خاتم ملكي فاخر', 'royal-ring', rings, '5.20', '425000', isNew: true),
      product(2, 'خاتم نقش ناعم', 'soft-ring', rings, '4.85', '398000'),
      product(3, 'سوار كلاسيكي', 'classic-bracelet', bracelets, '9.10', '746000', isNew: true),
      product(4, 'سوار فاخر', 'luxury-bracelet', bracelets, '11.40', '935000'),
      product(5, 'سلسلة ملكية', 'royal-necklace', necklaces, '13.60', '1115000'),
      product(6, 'سلسلة نسائية ناعمة', 'fine-necklace', necklaces, '7.75', '635000', isNew: true),
      product(7, 'طقم مناسبات', 'occasion-set', sets, '24.80', '2030000'),
      product(8, 'طقم عروس فاخر', 'bridal-set', sets, '31.25', '2560000', isNew: true),
    ];
  }
}
