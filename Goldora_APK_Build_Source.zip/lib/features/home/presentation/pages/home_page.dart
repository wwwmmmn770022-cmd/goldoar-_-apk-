import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../products/presentation/pages/product_details_page.dart';
import '../../../products/presentation/widgets/product_card.dart';
import '../../controllers/home_controller.dart';
import '../widgets/category_strip.dart';
import '../widgets/luxury_header.dart';
class HomePage extends GetView<HomeController> {
  const HomePage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: RefreshIndicator(
        onRefresh: controller.load,
        child: CustomScrollView(slivers: [
          const SliverToBoxAdapter(child: LuxuryHeader()),
          SliverToBoxAdapter(child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 24, 18, 10),
            child: Row(children: [
              const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('مختارات المتجر', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
                Text('قطع منتقاة بعناية', style: TextStyle(color: AppColors.muted)),
              ])),
              TextButton(onPressed: controller.load, child: const Text('تحديث')),
            ]),
          )),
          SliverToBoxAdapter(child: Obx(() => CategoryStrip(
            categories: controller.categories,
            selectedId: controller.selectedCategoryId.value,
            onSelected: controller.selectCategory,
          ))),
          const SliverToBoxAdapter(child: SizedBox(height: 14)),
          Obx(() {
            if (controller.isLoading.value) {
              return const SliverFillRemaining(child: Center(child: CircularProgressIndicator()));
            }
            if (controller.errorMessage.value != null) {
              return SliverFillRemaining(child: Center(child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const Icon(Icons.cloud_off_outlined, size: 52), const SizedBox(height: 12),
                  Text(controller.errorMessage.value!, textAlign: TextAlign.center), const SizedBox(height: 14),
                  FilledButton(onPressed: controller.load, child: const Text('إعادة المحاولة')),
                ]),
              )));
            }
            final products = controller.visibleProducts;
            if (products.isEmpty) return const SliverFillRemaining(child: Center(child: Text('لا توجد منتجات حالياً')));
            return SliverPadding(
              padding: const EdgeInsets.fromLTRB(18, 0, 18, 28),
              sliver: SliverGrid(
                delegate: SliverChildBuilderDelegate((context, i) {
                  final p = products[i];
                  return ProductCard(product: p, onTap: () => Get.to(() => ProductDetailsPage(product: p)));
                }, childCount: products.length),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                  childAspectRatio: 0.68,
                ),
              ),
            );
          }),
        ]),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: 0,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.grid_view_outlined), label: 'التصنيفات'),
          NavigationDestination(icon: Icon(Icons.search), label: 'البحث'),
          NavigationDestination(icon: Icon(Icons.favorite_border), label: 'المفضلة'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'حسابي'),
        ],
      ),
    );
  }
}
