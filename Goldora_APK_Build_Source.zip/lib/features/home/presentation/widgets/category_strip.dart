import 'package:flutter/material.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../products/data/models/product_models.dart';
class CategoryStrip extends StatelessWidget {
  const CategoryStrip({super.key, required this.categories, required this.selectedId, required this.onSelected});
  final List<CategoryModel> categories;
  final int? selectedId;
  final ValueChanged<int?> onSelected;
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 46,
      child: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 18),
        scrollDirection: Axis.horizontal,
        children: [
          _chip('الكل', null),
          ...categories.map((c) => _chip(c.name, c.id)),
        ],
      ),
    );
  }
  Widget _chip(String label, int? id) {
    final selected = selectedId == id;
    return Padding(
      padding: const EdgeInsetsDirectional.only(end: 8),
      child: ChoiceChip(
        label: Text(label),
        selected: selected,
        onSelected: (_) => onSelected(id),
        selectedColor: AppColors.charcoal,
        backgroundColor: AppColors.surface,
        side: const BorderSide(color: AppColors.line),
        labelStyle: TextStyle(color: selected ? Colors.white : AppColors.charcoal, fontWeight: FontWeight.w700),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
    );
  }
}
