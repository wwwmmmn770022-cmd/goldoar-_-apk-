import 'package:flutter/material.dart';
import '../../../../core/theme/app_colors.dart';
class LuxuryHeader extends StatelessWidget {
  const LuxuryHeader({super.key});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(22, 24, 22, 26),
      decoration: const BoxDecoration(
        color: AppColors.charcoal,
        borderRadius: BorderRadius.only(bottomLeft: Radius.circular(34), bottomRight: Radius.circular(34)),
      ),
      child: SafeArea(
        bottom: false,
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(
              width: 46, height: 46,
              decoration: BoxDecoration(color: AppColors.gold, borderRadius: BorderRadius.circular(15)),
              child: const Icon(Icons.diamond_outlined, color: AppColors.charcoal),
            ),
            const SizedBox(width: 12),
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('جولدورا', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800)),
              Text('مختارات من الذهب والمجوهرات', style: TextStyle(color: Color(0xFFCFC7BA), fontSize: 12)),
            ])),
            IconButton(onPressed: null, icon: Icon(Icons.favorite_border, color: Colors.white)),
          ]),
          const SizedBox(height: 22),
          const Text('أناقة تُحفظ قيمتها', style: TextStyle(color: AppColors.gold, fontSize: 30, fontWeight: FontWeight.w800, height: 1.3)),
          const SizedBox(height: 7),
          const Text('اكتشف تشكيلات مختارة بعناية، مع الوزن والعيار والسعر بوضوح.', style: TextStyle(color: Color(0xFFE7E0D4), height: 1.7)),
          const SizedBox(height: 18),
          TextField(
            readOnly: true,
            decoration: InputDecoration(
              hintText: 'ابحث عن خاتم، سلسلة، سوار...',
              prefixIcon: const Icon(Icons.search),
              fillColor: Colors.white,
              suffixIcon: Container(
                margin: const EdgeInsets.all(6),
                decoration: BoxDecoration(color: AppColors.gold, borderRadius: BorderRadius.circular(13)),
                child: const Icon(Icons.tune, color: AppColors.charcoal),
              ),
            ),
          ),
        ]),
      ),
    );
  }
}
