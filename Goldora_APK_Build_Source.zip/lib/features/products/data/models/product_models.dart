class CategoryModel {
  const CategoryModel({required this.id, required this.name, required this.slug});
  final int id;
  final String name;
  final String slug;
  factory CategoryModel.fromJson(Map<String, dynamic> json) => CategoryModel(
    id: (json['id'] as num?)?.toInt() ?? 0,
    name: json['name']?.toString() ?? '',
    slug: json['slug']?.toString() ?? '',
  );
}

class ProductMediaModel {
  const ProductMediaModel({required this.id, required this.type, required this.filePath, required this.isPrimary});
  final int id;
  final String type;
  final String filePath;
  final bool isPrimary;
  factory ProductMediaModel.fromJson(Map<String, dynamic> json) => ProductMediaModel(
    id: (json['id'] as num?)?.toInt() ?? 0,
    type: json['type']?.toString() ?? 'image',
    filePath: json['file_path']?.toString() ?? '',
    isPrimary: json['is_primary'] == true,
  );
}

class PriceModel {
  const PriceModel({required this.finalPrice, required this.currencyCode});
  final String finalPrice;
  final String currencyCode;
  factory PriceModel.fromJson(Map<String, dynamic> json) => PriceModel(
    finalPrice: json['final_price']?.toString() ?? '',
    currencyCode: json['currency_code']?.toString() ?? 'YER',
  );
}

class ProductItemModel {
  const ProductItemModel({
    required this.id,
    required this.sku,
    required this.weight,
    required this.status,
    required this.karatName,
    required this.priceAvailable,
    this.price,
  });
  final int id;
  final String sku;
  final String weight;
  final String status;
  final String karatName;
  final bool priceAvailable;
  final PriceModel? price;
  factory ProductItemModel.fromJson(Map<String, dynamic> json) {
    final priceJson = json['price'];
    final karat = json['karat'] is Map<String, dynamic> ? json['karat'] as Map<String, dynamic> : <String,dynamic>{};
    return ProductItemModel(
      id: (json['id'] as num?)?.toInt() ?? 0,
      sku: json['sku']?.toString() ?? '',
      weight: json['weight']?.toString() ?? '0',
      status: json['status']?.toString() ?? '',
      karatName: karat['name']?.toString() ?? '',
      priceAvailable: json['price_available'] == true,
      price: priceJson is Map<String, dynamic> ? PriceModel.fromJson(priceJson) : null,
    );
  }
}

class ProductModel {
  const ProductModel({
    required this.id,
    required this.name,
    required this.slug,
    required this.category,
    required this.media,
    required this.items,
    required this.isFeatured,
    required this.isNew,
    required this.viewsCount,
    this.shortDescription,
    this.description,
  });
  final int id;
  final String name;
  final String slug;
  final CategoryModel category;
  final List<ProductMediaModel> media;
  final List<ProductItemModel> items;
  final bool isFeatured;
  final bool isNew;
  final int viewsCount;
  final String? shortDescription;
  final String? description;

  String get primaryImage {
    if (media.isEmpty) return '';
    final primary = media.where((e) => e.isPrimary).toList();
    return (primary.isNotEmpty ? primary.first : media.first).filePath;
  }
  ProductItemModel? get firstAvailableItem {
    for (final item in items) {
      if (item.status == 'available') return item;
    }
    return items.isEmpty ? null : items.first;
  }

  factory ProductModel.fromJson(Map<String, dynamic> json) {
    final c = json['category'] is Map<String, dynamic> ? json['category'] as Map<String,dynamic> : <String,dynamic>{};
    final mediaJson = json['media'] is List ? json['media'] as List : const [];
    final itemsJson = json['items'] is List ? json['items'] as List : const [];
    return ProductModel(
      id: (json['id'] as num?)?.toInt() ?? 0,
      name: json['name']?.toString() ?? '',
      slug: json['slug']?.toString() ?? '',
      category: CategoryModel.fromJson(c),
      media: mediaJson.whereType<Map<String,dynamic>>().map(ProductMediaModel.fromJson).toList(),
      items: itemsJson.whereType<Map<String,dynamic>>().map(ProductItemModel.fromJson).toList(),
      isFeatured: json['is_featured'] == true,
      isNew: json['is_new'] == true,
      viewsCount: (json['views_count'] as num?)?.toInt() ?? 0,
      shortDescription: json['short_description']?.toString(),
      description: json['description']?.toString(),
    );
  }
}
