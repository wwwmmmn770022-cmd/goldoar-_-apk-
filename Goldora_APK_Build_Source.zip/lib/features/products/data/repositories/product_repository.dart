import '../../../../core/config/app_config.dart';
import '../../../../core/network/api_client.dart';
import '../models/product_models.dart';
class ProductRepository {
  ProductRepository(this._client);
  final ApiClient _client;
  Future<List<ProductModel>> fetchProducts({int page = 1}) async {
    final response = await _client.dio.get('/products', queryParameters: {
      'store_id': AppConfig.storeId,
      'page': page,
      'per_page': 24,
    });
    final body = response.data;
    final list = body is Map<String,dynamic> && body['data'] is List ? body['data'] as List : const [];
    return list.whereType<Map<String,dynamic>>().map(ProductModel.fromJson).toList();
  }
  Future<ProductModel> fetchProduct(String slug) async {
    final response = await _client.dio.get('/products/$slug', queryParameters: {'store_id': AppConfig.storeId});
    final body = response.data;
    final data = body is Map<String,dynamic> && body['data'] is Map<String,dynamic> ? body['data'] as Map<String,dynamic> : <String,dynamic>{};
    return ProductModel.fromJson(data);
  }
}
