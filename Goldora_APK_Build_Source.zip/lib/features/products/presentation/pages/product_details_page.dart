import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/utils/media_url.dart';
import '../../../../core/utils/price_formatter.dart';
import '../../data/models/product_models.dart';
class ProductDetailsPage extends StatelessWidget {
  const ProductDetailsPage({super.key, required this.product});
  final ProductModel product;
  @override
  Widget build(BuildContext context) {
    final item = product.firstAvailableItem;
    final images = product.media.where((m) => m.type == 'image').toList();
    return Scaffold(
      appBar: AppBar(title: Text(product.name), actions: [IconButton(onPressed: () {}, icon: const Icon(Icons.favorite_border))]),
      body: ListView(children: [
        SizedBox(
          height: 390,
          child: PageView.builder(
            itemCount: images.isEmpty ? 1 : images.length,
            itemBuilder: (context, i) {
              if (images.isEmpty) return Container(color: const Color(0xFFF0E9DC), child: const Icon(Icons.diamond_outlined, size: 90, color: AppColors.deepGold));
              return CachedNetworkImage(imageUrl: MediaUrl.resolve(images[i].filePath), fit: BoxFit.cover, errorWidget: (_,__,___)=>const Icon(Icons.broken_image_outlined));
            },
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(20),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(product.category.name, style: const TextStyle(color: AppColors.deepGold, fontWeight: FontWeight.w800)),
            const SizedBox(height: 6),
            Text(product.name, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
            const SizedBox(height: 12),
            if (item != null) Wrap(spacing: 8, runSpacing: 8, children: [
              _info('العيار', item.karatName), _info('الوزن', '${item.weight} جم'), _info('الكود', item.sku),
            ]),
            const SizedBox(height: 18),
            Text(
              item?.priceAvailable == true && item?.price != null ? PriceFormatter.format(item!.price!.finalPrice, item.price!.currencyCode) : 'السعر عند الطلب',
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: AppColors.deepGold),
            ),
            const SizedBox(height: 18),
            if ((product.description ?? product.shortDescription ?? '').isNotEmpty)
              Text(product.description ?? product.shortDescription ?? '', style: const TextStyle(height: 1.8, color: AppColors.muted)),
            const SizedBox(height: 110),
          ]),
        ),
      ]),
      bottomNavigationBar: SafeArea(
        minimum: const EdgeInsets.all(14),
        child: Row(children: [
          Expanded(child: OutlinedButton.icon(onPressed: () {}, icon: const Icon(Icons.chat_outlined), label: const Text('واتساب'), style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(54)))),
          const SizedBox(width: 10),
          Expanded(flex: 2, child: FilledButton.icon(onPressed: item?.status == 'available' ? () {} : null, icon: const Icon(Icons.lock_outline), label: const Text('احجز القطعة'), style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(54), backgroundColor: AppColors.charcoal, foregroundColor: Colors.white))),
        ]),
      ),
    );
  }
  Widget _info(String title, String value) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
    decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(13), border: Border.all(color: AppColors.line)),
    child: RichText(text: TextSpan(style: const TextStyle(color: AppColors.charcoal, fontFamilyFallback: []), children: [
      TextSpan(text: '$title: ', style: const TextStyle(color: AppColors.muted)), TextSpan(text: value, style: const TextStyle(fontWeight: FontWeight.w800)),
    ])),
  );
}
