import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/utils/media_url.dart';
import '../../../../core/utils/price_formatter.dart';
import '../../data/models/product_models.dart';
class ProductCard extends StatelessWidget {
  const ProductCard({super.key, required this.product, required this.onTap});
  final ProductModel product;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) {
    final item = product.firstAvailableItem;
    final imageUrl = MediaUrl.resolve(product.primaryImage);
    return InkWell(
      borderRadius: BorderRadius.circular(22),
      onTap: onTap,
      child: Ink(
        decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(22), border: Border.all(color: AppColors.line)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(
            child: Stack(children: [
              ClipRRect(
                borderRadius: const BorderRadius.vertical(top: Radius.circular(21)),
                child: imageUrl.isEmpty
                    ? Container(color: const Color(0xFFF0E9DC), child: const Center(child: Icon(Icons.diamond_outlined, size: 48, color: AppColors.deepGold)))
                    : CachedNetworkImage(
                        imageUrl: imageUrl,
                        width: double.infinity,
                        height: double.infinity,
                        fit: BoxFit.cover,
                        placeholder: (_, __) => Container(color: const Color(0xFFF0E9DC)),
                        errorWidget: (_, __, ___) => const Center(child: Icon(Icons.broken_image_outlined)),
                      ),
              ),
              if (product.isNew)
                PositionedDirectional(top: 10, start: 10, child: _badge('جديد')),
              const PositionedDirectional(top: 7, end: 7, child: CircleAvatar(radius: 18, backgroundColor: Colors.white, child: Icon(Icons.favorite_border, size: 19, color: AppColors.charcoal))),
            ]),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 11, 12, 13),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(product.category.name, style: const TextStyle(fontSize: 11, color: AppColors.deepGold, fontWeight: FontWeight.w700)),
              const SizedBox(height: 3),
              Text(product.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
              const SizedBox(height: 6),
              if (item != null) Text('${item.karatName} • ${item.weight} جم', style: const TextStyle(color: AppColors.muted, fontSize: 11)),
              const SizedBox(height: 7),
              Text(
                item?.priceAvailable == true && item?.price != null
                    ? PriceFormatter.format(item!.price!.finalPrice, item.price!.currencyCode)
                    : 'السعر عند الطلب',
                style: const TextStyle(color: AppColors.charcoal, fontWeight: FontWeight.w900, fontSize: 14),
              ),
            ]),
          ),
        ]),
      ),
    );
  }
  Widget _badge(String text) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
    decoration: BoxDecoration(color: AppColors.gold, borderRadius: BorderRadius.circular(10)),
    child: Text(text, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: AppColors.charcoal)),
  );
}
