import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'app/app.dart';
import 'core/network/api_client.dart';
import 'core/storage/token_storage.dart';
import 'features/home/controllers/home_controller.dart';
import 'features/products/data/repositories/product_repository.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  final storage = TokenStorage();
  final apiClient = ApiClient(storage);
  Get.put<TokenStorage>(storage, permanent: true);
  Get.put<ApiClient>(apiClient, permanent: true);
  Get.put<ProductRepository>(ProductRepository(apiClient), permanent: true);
  Get.put<HomeController>(HomeController(Get.find<ProductRepository>()));

  runApp(const GoldoraApp());
}
